const ADMIN_ACTIONS = [
  { status: 2, message: "Admin has approved your campaign" },
  { status: 4, message: "Admin has declined your campaign" },
];

module.exports = { ADMIN_ACTIONS };
