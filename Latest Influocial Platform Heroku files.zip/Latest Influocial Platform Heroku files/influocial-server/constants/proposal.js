const PROPOSAL_ALERTS = [
  { status: 1, message: "has applied on your campaign for" },
];

module.exports = { PROPOSAL_ALERTS };
