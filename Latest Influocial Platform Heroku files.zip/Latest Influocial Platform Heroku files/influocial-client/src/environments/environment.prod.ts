// export const environment = {
//   production: true,
//   apiUrl: 'http://134.209.189.120',
//   file_url: 'http://134.209.189.120',
//   facebookAppId: '863617834458750',
//   facebookSecret: 'f1fd4b235451c805434dbc0663c821bc',
//   payPalClientId:
//     'AcxAICSt_18Q5Kd9N5D5VClGIyhIWByuq9Dt_fOAMDWuD5xjpjBUkZCw--AvdVtNDhA3nkw90C-legnA'
// };

// PROD

export const environment = {
  production: false,
  apiUrl: 'https://influocial-server.herokuapp.com',
  file_url: 'https://influocial-server.herokuapp.com',
  facebookAppId: '863617834458750',
  facebookSecret: 'f1fd4b235451c805434dbc0663c821bc',
  payPalClientId: 'AeSMjKG4phjf93lqnwbo58yueyMSPBLGuFQ26xgdU7qkKITkpQN3zxFxcaE5-8eNjuDLXLlEkjGciK8Q',
};
