// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiUrl: 'https://influocial-server.herokuapp.com',
  file_url: 'https://influocial-server.herokuapp.com',
  facebookAppId: '863617834458750',
  facebookSecret: 'f1fd4b235451c805434dbc0663c821bc',
  payPalClientId: 'AeSMjKG4phjf93lqnwbo58yueyMSPBLGuFQ26xgdU7qkKITkpQN3zxFxcaE5-8eNjuDLXLlEkjGciK8Q',
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
