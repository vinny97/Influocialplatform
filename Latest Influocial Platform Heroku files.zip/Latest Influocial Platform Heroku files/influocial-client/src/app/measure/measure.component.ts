import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-measure',
  templateUrl: './measure.component.html',
})
export class MeasureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
