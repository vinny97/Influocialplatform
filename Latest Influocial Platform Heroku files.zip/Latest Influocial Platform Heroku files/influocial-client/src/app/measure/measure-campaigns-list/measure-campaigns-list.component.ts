import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-measure-campaigns-list',
  templateUrl: './measure-campaigns-list.component.html',
})
export class MeasureCampaignsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
