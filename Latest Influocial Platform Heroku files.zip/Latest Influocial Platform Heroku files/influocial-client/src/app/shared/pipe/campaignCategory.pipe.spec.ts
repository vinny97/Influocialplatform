/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CampaignCategoryPipe } from './campaignCategory.pipe';

describe('Pipe: CampaignCategorye', () => {
  it('create an instance', () => {
    let pipe = new CampaignCategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
