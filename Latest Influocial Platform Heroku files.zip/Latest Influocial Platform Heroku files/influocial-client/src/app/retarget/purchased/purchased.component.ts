import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchased',
  templateUrl: './purchased.component.html',
  styleUrls: ['./purchased.component.css']
})
export class PurchasedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
