import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collabs',
  templateUrl: './collabs.component.html',
})
export class CollabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
