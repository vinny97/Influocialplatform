export const ROLES = [
  { id: 1, name: 'Super Admin' },
  { id: 2, name: 'Influencer' },
  { id: 3, name: 'Agency' },
  { id: 2, name: 'Brand' },
];
