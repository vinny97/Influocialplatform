export const PRODUCT_PHYSICAL_OPTIONS = [
    { id: 1, name: 'Influencer needs to purchase product' },
    { id: 2, name: 'Influencers need to pay collateral(Expensive /High value product)' },
    { id: 3, name: 'I will ship the product to the influencer' },
];
