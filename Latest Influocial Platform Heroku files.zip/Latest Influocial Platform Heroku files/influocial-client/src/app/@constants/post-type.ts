export const POST_TYPES = [
    { id: 1, name: 'Posts' },
    { id: 2, name: 'Stories' },
];
