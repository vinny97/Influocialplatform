export const genders = [
  {id: 0, name: 'All'},
  {id: 1, name: 'Male'},
  {id: 2, name: 'Female'},
];
