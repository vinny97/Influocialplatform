export const OUTRIGHT_STATUS = [
    { id: 0, name: '---All---' },
    { id: 1, name: 'Awaiting for Bid' },
    { id: 2, name: 'Bid sent' },
    { id: 3, name: 'Approved' },
    { id: 4, name: 'Declined' },
];
