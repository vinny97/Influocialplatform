export const objectives = [
  {id: 0, name: 'Drive awareness to website'},
  {id: 1, name: 'Drive traffic to site'},
  {id: 2, name: 'Launching a new product'},
  {id: 3, name: 'Trying out influencer marketing'},
  {id: 4, name: 'Create relationships with influencer'},
  {id: 5, name: 'Other'},
];
