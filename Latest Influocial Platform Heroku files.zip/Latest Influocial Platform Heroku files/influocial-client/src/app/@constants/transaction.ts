export const TRANSACTION_STATUS = [
  { id: 1, name: 'Prending/Attempted' },
  { id: 2, name: 'Successful' },
  { id: 3, name: 'Unsuccessful' },
];
