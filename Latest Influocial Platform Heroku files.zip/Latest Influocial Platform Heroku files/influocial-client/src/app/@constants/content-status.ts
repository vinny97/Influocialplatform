export const PROPOSAL_CONTENT_STATUS = [
  { id: 0, name: 'Not Applicable' },
  { id: 1, name: 'Waiting for confirmation' },
  { id: 2, name: 'Approved' },
  { id: 3, name: 'Submit' },
  { id: 4, name: 'Published' },
];
