export const CAMPAIGN_DURATION = [
    10, 15, 25, 35, 50
];