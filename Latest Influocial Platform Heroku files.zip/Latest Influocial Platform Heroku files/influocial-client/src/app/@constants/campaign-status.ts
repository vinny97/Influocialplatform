export const CAMPAIGN_STATUS = [
    { id: 1, name: 'In Review' },
    { id: 2, name: 'Active' },
    { id: 3, name: 'In Active' },
    { id: 4, name: 'Rejected' },
    { id: 5, name: 'Completed' },
];