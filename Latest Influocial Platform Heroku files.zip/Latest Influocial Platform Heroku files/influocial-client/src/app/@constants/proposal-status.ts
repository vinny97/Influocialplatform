export const PROPOSAL_STATUS = [
  { id: 1, name: 'Applied' },
  { id: 2, name: 'Rebid Requested' },
  { id: 3, name: 'Approved' },
  { id: 4, name: 'Declined' },
  { id: 5, name: 'Published' },
];
