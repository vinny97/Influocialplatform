export const CAMPAIGN_TYPE = [
    { id: 0, name: 'All' },
    { id: 1, name: 'Influencer' },
    { id: 2, name: 'ShoutOut' },
];