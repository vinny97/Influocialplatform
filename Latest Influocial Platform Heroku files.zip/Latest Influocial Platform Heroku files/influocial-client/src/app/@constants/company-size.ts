export const COMPANY_SIZE = [
    { id: 1, name: '10-20 Employees' },
    { id: 2, name: '20-50 Employees' },
    { id: 3, name: '50-100 Employees' },

];