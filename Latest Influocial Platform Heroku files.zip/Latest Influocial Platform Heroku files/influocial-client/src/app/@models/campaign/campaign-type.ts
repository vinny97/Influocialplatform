export enum CampaignType {
  Influencer = 1,
  ShoutOut = 2,
}
