export enum UserStatus {
    Active = 1,
    InActive = 2,
}