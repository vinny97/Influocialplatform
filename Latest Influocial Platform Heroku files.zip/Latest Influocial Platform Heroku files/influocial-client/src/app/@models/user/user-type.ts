export enum UserType {
  admin = 1,
  influencer = 2,
  brand = 3,
  agency = 4,
}
