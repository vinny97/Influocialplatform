export class AdminStats {
    inReviewCampaigns: number = 0;
    activeCampaigns: number = 0;
    completedCampaigns: number = 0;
    totalUsers: number = 0;
    totalInfluencer: number = 0;
    totalBrandsAndAgency: number = 0;
}
